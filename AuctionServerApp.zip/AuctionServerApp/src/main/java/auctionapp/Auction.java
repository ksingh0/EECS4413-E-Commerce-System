package auctionapp;

import java.util.Timer;

public class Auction {
	int id;
	int itemID;
	int highestBidID;
	double highestPrice;
	long endTime;
	
	public Auction() {
		//constructor
	}
	
	//constructor for testing - remove later.
	public Auction(String test) {
		//constructor
		this.id = 6;
		this.itemID = 66;
		this.highestBidID = 1;
		this.highestPrice = 100.0;
		this.endTime = 123456;
	}
	
	//other methods
	public void createTimer() {
		Timer timer = new Timer();
		timer.schedule(new AuctionTimerTask(this.id), this.endTime*1000 - System.currentTimeMillis());
	}
	
	//method to cancel timer ... if auction is cancelled? but...how to find the timer...
	//
	
	//check if auction is over - (elsewhere) if true, then users are served a "Pay Now" page.
	public boolean isEnded() {
		return (this.endTime*1000 <= System.currentTimeMillis());
	}
	
	//setters
	public void setID(int id) {
		this.id = id;
	}
	
	public void setItemID(int itemID) {
		this.itemID = itemID;
	}
	
	public void setHighestBidID(int highestBidID) {
		this.highestBidID = highestBidID;
	}
	
	public void setHighestPrice(double price) {
		this.highestPrice = price;
	}
	
	public void setEndTime(int endTime) {
		this.endTime = endTime;
	}
	
	//getters
	public int getId() {
		return this.id;
	}
	
	public int getItemID() {
		return this.itemID;
	}
	
	public int getHighestBidID() {
		return this.highestBidID;
	}
	
	public double getHighestPrice() {
		return this.highestPrice;
	}
	
	public long getEndTime() {
		return this.endTime;
	}
}
