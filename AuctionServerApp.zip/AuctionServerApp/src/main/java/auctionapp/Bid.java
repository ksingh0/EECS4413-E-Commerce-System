package auctionapp;

public class Bid {
	int bidID;
	int auctionID;
	int userID; //String or int? 
	int bidTime;
	double amount;
	
	
	public Bid() {
		
	}
	
	//verify
	public void verifyBid(Auction auction) {
		if (this.getAmount() <= auction.getHighestPrice()) {
			throw new IllegalArgumentException("Bid amount must be greater than the current highest bid!");
		}
		
	}
	
	//setters
	public void setBidID(int bidID) {
		this.bidID = bidID;
	}
	
	public void setAuctionID(int auctionID) {
		this.auctionID = auctionID;
	}
	
	public void setUserID(int userID) {
		this.userID = userID;
	}
	
	public void setBidTime(int bidTime) {
		this.bidTime = bidTime;
	}
	
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	
	//getters
	public int getBidID() {
		return this.bidID;
	}
	
	public int getAuctionID() {
		return this.auctionID;
	}
	
	public int getUserID() {
		return this.userID;
	}
	
	public int getBidTime() {
		return this.bidTime;
	}
	
	public double getAmount() {
		return this.amount;
	}
	
}
